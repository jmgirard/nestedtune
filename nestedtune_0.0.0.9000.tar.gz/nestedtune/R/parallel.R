# Detecting and recording the outer-loop dispatch branch.
#
# nestedtune parallelizes over outer folds and never inside them: inner tuning
# runs with control_grid(allow_par = FALSE), because nested parallelism
# oversubscribes cores. Detection mirrors tune's own so that "parallel" means
# the same thing in both packages (D-018) -- mirai installed, and at least two
# connected daemons. Below that tune stays sequential, and so do we.

# Split out so the threshold can be tested without daemons, and so the
# installed-or-not branch can be mocked.
is_mirai_installed <- function() {
  rlang::is_installed("mirai")
}

mirai_workers <- function() {
  if (!is_mirai_installed()) {
    return(0L)
  }
  # status() reports the live daemon pool; connections is NULL before daemons()
  # has ever been called in the session.
  workers <- mirai::status()$connections
  if (length(workers) != 1L || is.na(workers)) {
    return(0L)
  }
  as.integer(workers)
}

use_parallel <- function(workers = mirai_workers()) {
  length(workers) == 1L && !is.na(workers) && workers >= 2L
}

# Which branch the last dispatch took.
#
# This is deliberately NOT stored on the results object. BC1 requires both that
# a parallel result be identical() to its serial counterpart and that a test be
# able to prove the parallel branch actually ran; an attribute on the result
# would satisfy the second by breaking the first. An internal record satisfies
# both, and keeps the public surface unchanged.
the <- new.env(parent = emptyenv())

record_dispatch <- function(branch) {
  the$last_dispatch <- branch
  invisible(branch)
}

last_dispatch <- function() {
  the$last_dispatch
}

reset_dispatch_record <- function() {
  the$last_dispatch <- NULL
  invisible(NULL)
}

# Run every fold, serially or across daemons.
#
# `payloads` is one self-contained list per fold -- split, inner rset, and the
# fold's two seeds. Mapping over per-fold payloads rather than passing the whole
# design as a shared argument means a worker receives only the fold it runs.
#
# The seeds are already drawn and assigned by position before this is called
# (D-011), so nothing here draws, and a fold's result cannot depend on where or
# when it runs. That is the whole reason the loop is safe to parallelize.
dispatch_folds <- function(payloads, object, grid, metrics,
                           call = rlang::caller_env()) {
  if (!use_parallel()) {
    record_dispatch("serial")
    return(lapply(payloads, fold_task, object = object, grid = grid, metrics = metrics))
  }

  check_daemons_can_load(call = call)

  record_dispatch("parallel")
  # The task is sent with its environment stripped to the global one. Left
  # attached, the nestedtune namespace travels with the closure and mirai warns
  # that the package "may not be available when loading" on every dispatch --
  # and where it truly is unavailable the environment silently degrades to the
  # global one anyway (RR03 Q5). Since the body resolves the namespace by name
  # regardless, carrying it buys nothing and costs a warning per fold.
  task <- fold_task
  environment(task) <- globalenv()

  mapped <- mirai::mirai_map(
    .x = payloads,
    .f = task,
    .args = list(object = object, grid = grid, metrics = metrics)
  )
  # A plain blocking collect: results in place, failures as values. mirai's
  # `.stop` would abort the whole run on the first failing fold and discard the
  # completed ones -- exactly what M03 exists to prevent.
  collected <- mirai::collect_mirai(mapped)
  lapply(collected, classify_fold_result, call = call)
}

# One round-trip before any fold is dispatched, to fail on the setup error users
# will actually make.
#
# Daemons are separate R processes: they can load nestedtune only from an
# installed library, and `devtools::load_all()` does not reach them. Without this
# check that mistake surfaces as every fold failing with the same opaque note --
# a run that looks like a statistical catastrophe and is really a library path
# (RR03 rec 8). One round-trip buys an error that names the fix.
# Bounded, because a daemon that never connects would otherwise block here
# forever. mirai reports connections from the pool's configuration, so a daemon
# that died during startup -- one whose own library is broken, say -- is counted
# but will never answer. This is deliberately NOT the per-fold timeout RR03
# rejected: a model fit has no defensible time limit, but a round-trip that only
# calls requireNamespace() does, and bounding it converts an unbreakable hang
# into an error naming the cause (M07-D6).
#
# The bound is an option rather than an argument (D-020): it tunes
# infrastructure and never anything statistical, so no result depends on it and
# nested_tune_grid()'s signature stays what it was. Non-finite is refused along
# with non-positive and non-numeric (M10-D2) -- an `Inf` bound is not a bound,
# and would hand back the unbreakable hang this exists to convert into an error.
default_preflight_timeout_ms <- 30000L

preflight_timeout <- function(call = rlang::caller_env()) {
  value <- getOption("nestedtune.preflight_timeout", default_preflight_timeout_ms)
  usable <- is.numeric(value) && length(value) == 1L &&
    !is.na(value) && is.finite(value) && value > 0
  if (!usable) {
    cli::cli_abort(
      c(
        "{.code options(nestedtune.preflight_timeout)} must be a single
         positive, finite number of milliseconds.",
        x = if (is.numeric(value) && length(value) == 1L) {
          "It is {.val {value}}."
        } else {
          "It is {.obj_type_friendly {value}}."
        }
      ),
      class = "nestedtune_bad_preflight_timeout",
      call = call
    )
  }
  as.numeric(value)
}

# Ask every connected daemon, not whichever one is free.
#
# The M07 defect: a single mirai() task is taken by ONE daemon, so a pool that
# is heterogeneous -- a respawned daemon, differing library paths -- had one
# loadable daemon answer for all of them, and every fold that landed elsewhere
# came back as an opaque worker failure. everywhere() is the mechanism that
# reaches all of them: verified to return one element per connected daemon
# (distinct pids), and to queue behind a daemon that is busy rather than skip it.
#
# It carries no `.timeout` of its own, so the bound is a poll on unresolved()
# to a deadline followed by stop_mirai(), which resolves every outstanding
# element to errorValue 20 and leaves the pool usable (both verified by
# execution, M10 T1).
#
# Answers are then read one element at a time from `$data`, which yields
# `unresolvedValue` for anything still outstanding, rather than through the
# map's own `[` -- that collects, and collecting BLOCKS until every element
# resolves. Reading per element cannot block at all, so the bound holds even if
# stop_mirai() leaves something behind, and nothing here can hang however mirai
# behaves.
daemons_load_status <- function(package = "nestedtune",
                                timeout = preflight_timeout(call = call),
                                call = rlang::caller_env()) {
  # Forced before anything is dispatched. Left lazy, the bound is not read until
  # after everywhere() has already sent the probe, so a typo in the option costs
  # a full cold load on every daemon before the user is told the option is bad.
  force(timeout)

  probe <- mirai::everywhere(
    requireNamespace(package, quietly = TRUE),
    .args = list(package = package)
  )
  deadline <- Sys.time() + timeout / 1000
  while (mirai::unresolved(probe) && Sys.time() < deadline) {
    Sys.sleep(0.05)
  }
  if (mirai::unresolved(probe)) {
    mirai::stop_mirai(probe)
  }
  answers <- lapply(seq_along(probe), function(i) probe[[i]]$data)
  preflight_outcome(answers, timeout = timeout, package = package)
}

# One daemon's answer, validated positively.
#
# Same discipline as classify_fold_result(): recognise the expected shape and
# treat everything else as a non-answer, rather than trying to enumerate the
# ways mirai can hand back something that is not a logical. A stopped probe
# yields errorValue 20; a daemon that died mid-probe yields something else
# again. Neither is a report that the package is missing, so neither may be
# reported as one.
loaded_answer <- function(x) {
  if (is.logical(x) && length(x) == 1L && !is.na(x)) as.logical(x) else NA
}

# The three-way outcome, kept separate from both the probing and the message so
# every branch is reachable in a test without a daemon pool.
#
# A pool can fail both ways at once, so the record carries counts rather than a
# bare verdict: the load failure takes the class, because installing is the
# actionable fix, and the message still names the non-answers (M10-D1).
preflight_outcome <- function(answers, timeout = NA_real_,
                              package = "nestedtune") {
  answers <- vapply(as.list(answers), loaded_answer, logical(1))
  total <- length(answers)
  cannot_load <- sum(!answers, na.rm = TRUE)
  no_answer <- sum(is.na(answers))
  outcome <- if (cannot_load > 0L) {
    "cannot_load"
  } else if (no_answer > 0L || total == 0L) {
    "no_response"
  } else {
    "ok"
  }
  list(
    outcome = outcome,
    total = total,
    cannot_load = cannot_load,
    no_answer = no_answer,
    timeout = timeout,
    package = package
  )
}

# `status` is an argument so both failure branches are reachable in a test
# without breaking a library path. Doing that for real also stops the daemon
# loading *mirai*, which kills it at startup and hangs the very probe under test
# -- found the hard way when it hung `R CMD check` for 39 minutes. The
# heterogeneous pool AC1 asks for is built in test-parallel-detection.R, where
# the scratch library keeps mirai and drops only the probed package.
check_daemons_can_load <- function(status = daemons_load_status(call = call),
                                   call = rlang::caller_env()) {
  if (identical(status$outcome, "ok")) {
    return(invisible(TRUE))
  }

  n_total <- status$total
  n_cannot <- status$cannot_load
  n_silent <- status$no_answer
  package <- status$package
  # Spelled out rather than interpolated raw: cli renders a numeric through
  # as.character(), which gives "3e+05" for a 300000 ms bound -- scientific
  # notation in the very bullet telling the user to raise that number.
  timeout <- format(status$timeout, scientific = FALSE, trim = TRUE)

  if (identical(status$outcome, "cannot_load")) {
    bullets <- c(
      "{n_cannot} of {n_total} mirai daemon{?s} cannot load {.pkg {package}}.",
      i = "Daemons are separate R processes and load the package from an
           installed library; {.fn devtools::load_all} does not reach them.",
      i = "Install the package, or prime the daemons with
           {.code mirai::everywhere(pkgload::load_all('<path>'))}."
    )
    if (n_silent > 0L) {
      bullets <- c(bullets, i = "A further {n_silent} daemon{?s} did not answer
                                 within {timeout} ms.")
    }
    cli::cli_abort(
      c(bullets, i = "Alternatively call {.code mirai::daemons(0)} to run
                      serially -- results are identical either way."),
      class = c("nestedtune_daemons_cannot_load", "nestedtune_daemons_unusable"),
      call = call
    )
  }

  # No daemon reported the package missing -- they did not reply at all, so the
  # remedies above would tell a user to install what they already have.
  bullets <- "The mirai daemons did not answer the startup check within
              {timeout} ms."
  if (n_total > 0L) {
    bullets <- c(bullets, i = "{n_silent} of {n_total} daemon{?s} did not reply.")
  }
  cli::cli_abort(
    c(
      bullets,
      i = "A daemon that died during startup is still counted as a connection
           and never replies.",
      i = "If the daemons are merely slow -- a loaded machine, a scanned
           library -- raise the bound with
           {.code options(nestedtune.preflight_timeout = <ms>)}.",
      i = "Alternatively call {.code mirai::daemons(0)} to run serially --
           results are identical either way."
    ),
    class = c("nestedtune_daemons_no_response", "nestedtune_daemons_unusable"),
    call = call
  )
}

# What a worker handed back, turned into a fold record.
#
# Classification is positive: a fold record is recognised by its shape, and
# everything else is a worker failure. The two shapes mirai can return instead
# defeat the obvious test -- neither `miraiError` nor the bare `errorValue` from
# a daemon that died inherits "condition", and `conditionMessage()` raises on
# the latter rather than describing it (RR03 Q4, verified). Asking "is this an
# error?" therefore mistakes both for successes; asking "is this a fold record?"
# cannot.
classify_fold_result <- function(x, call = rlang::caller_env()) {
  if (is_fold_record(x)) {
    return(x)
  }
  if (inherits(x, "miraiInterrupt")) {
    # Not a fold failure: the user stopped the run. Recording it as one would
    # report a cancelled run as a design that executed and partly failed (IP4).
    cli::cli_abort(
      c(
        "Run interrupted while waiting on outer folds.",
        i = "No results are returned; the caller's RNG state is restored."
      ),
      class = "nestedtune_interrupted",
      call = call
    )
  }
  if (is_cancelled_value(x)) {
    # Same inversion as the interrupt above, reached by a different route and
    # carrying none of its classes -- which is why M07 shipped with this path
    # open. The subclass keeps a handler for the general case working.
    cli::cli_abort(
      c(
        "Run cancelled while waiting on outer folds.",
        i = "The tasks were stopped before every outer fold had run, so the
             folds that did finish do not describe the requested design.",
        i = "No results are returned; the caller's RNG state is restored."
      ),
      class = c("nestedtune_cancelled", "nestedtune_interrupted"),
      call = call
    )
  }
  failed_fold("worker", NULL, NULL, message = worker_failure_message(x))
}

# nanonext's ECANCELED, which is what `mirai::stop_mirai()` leaves behind.
#
# Allowlisted to this one value on M09-D1's probe: 20 appears only under
# cancellation -- in flight and still queued alike, and for every task in a
# stopped `mirai_map()`, not just the one running. Deliberately NOT extended to
# 19 (ECONNRESET), which the same probe found under a `daemons(0)` teardown AND
# a daemon dying mid-fold, with identical classes and nothing to separate them;
# aborting on it would discard every completed fold whenever one worker died,
# which is what M03 exists to prevent. Anything unrecognised keeps the
# failed_fold() default for the same reason.
cancel_error_value <- 20L

is_cancelled_value <- function(x) {
  # Positive validation of the shape, per the same reasoning is_fold_record()
  # rests on: a real interrupt is an empty *string* carrying `errorValue`, and
  # a miraiError is the task's message, so `is.integer()` is what keeps both
  # out of this branch rather than an ordering accident.
  inherits(x, "errorValue") &&
    is.integer(x) &&
    length(x) == 1L &&
    !is.na(x) &&
    x == cancel_error_value
}

is_fold_record <- function(x) {
  is.list(x) &&
    is.logical(x$completed) &&
    length(x$completed) == 1L &&
    all(c("metrics", "selected", "notes") %in% names(x))
}

worker_failure_message <- function(x) {
  # Dispatched on class rather than through mirai's predicates, so classification
  # needs nothing loaded. Order matters: a miraiError is also an errorValue.
  if (inherits(x, "miraiError")) {
    # A miraiError does carry the task's own error message.
    return(conditionMessage(x))
  }
  if (inherits(x, "errorValue")) {
    # A bare errorValue is an integer code. nanonext names it ("19 | Connection
    # reset"); it always ships with mirai, but it is not a declared dependency
    # of this package, so it is reached only if present and the code stands
    # alone otherwise.
    named <- tryCatch(
      getExportedValue("nanonext", "nng_error")(as.integer(x)),
      error = function(cnd) NULL
    )
    return(paste0(
      "The worker failed with mirai error value ", as.integer(x),
      if (!is.null(named)) paste0(" (", named, ")") else ""
    ))
  }
  "The worker returned something that is not a fold record."
}

# One fold, as it runs on a worker.
#
# The namespace is resolved by name rather than captured: a closure carrying the
# nestedtune namespace as its environment loses that environment when a daemon
# cannot reconstruct it, silently falling back to the global environment where
# none of the package's internals resolve (RR03 Q5). Looking the namespace up
# here either works or fails loudly, and the pre-flight check makes it the
# latter before any fold is dispatched.
fold_task <- function(payload, object, grid, metrics) {
  ns <- asNamespace("nestedtune")
  ns$nested_fold_fit(
    split = payload$split,
    inner = payload$inner,
    seeds = payload$seeds,
    object = object,
    grid = grid,
    metrics = metrics
  )
}
